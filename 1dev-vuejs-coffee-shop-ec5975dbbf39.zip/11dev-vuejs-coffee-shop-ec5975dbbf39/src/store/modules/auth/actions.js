import api from '@/services/axios-interceptor';
import LOGIN_USER from './mutation-types';
import { LOGIN_LINK } from '@/links';

const login = async ({ commit }, payload) => {
  commit(LOGIN_USER.PENDING);
  try {
    const response = await api.post(LOGIN_LINK, payload);
    if (response.data) {
      localStorage.setItem('token', btoa(JSON.stringify(response.data.data)));
      commit(LOGIN_USER.SUCCESS);
    }
  } catch (error) {
    commit(LOGIN_USER.FAILED, error.response.data);
  }
};

export default {
  login,
};
