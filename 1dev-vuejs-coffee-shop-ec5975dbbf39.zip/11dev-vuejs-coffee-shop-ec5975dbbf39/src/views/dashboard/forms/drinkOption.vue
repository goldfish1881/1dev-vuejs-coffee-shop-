<template>
  <v-form
    ref="form"
    v-model="validForm"
  >
    <v-card-text>
      <v-container>
        <v-text-field
          :value="name"
          :rules="rules.name"
          label="Name"
          clearable
          @change="onTypeName"
        />
        <v-text-field
          :value="price"
          type="number"
          hint="The value must be positive or leave it empty if you do not want the price to be"
          :rules="rules.price"
          label="Price"
          clearable
          @change="onTypePrice"
        />
      </v-container>
    </v-card-text>
    <v-card-actions>
      <span
        v-if="updatedDataError"
        class="red--text pl-5"
      >No modified data.</span>
      <v-spacer />
      <v-btn
        color="blue darken-1"
        text
        @click="DIALOG_TOGGLE()"
      >
        Cancel
      </v-btn>
      <v-btn
        :disabled="!validForm"
        color="blue darken-1"
        text
        @click="submitForm"
      >
        Save
      </v-btn>
    </v-card-actions>
  </v-form>
</template>

<script>
import { mapState, mapActions, mapMutations } from 'vuex';

export default {
  name: 'DrinkOptionForm',
  data() {
    return {
      validForm: true,
      name: null,
      price: null,
      updatedDataError: false,
      newData: {},
    };
  },
  computed: {
    ...mapState('drinkOptions', ['formData']),
    createRules() {
      return {
        name: [
          v => !!v || 'Name is required',
          v => (v && v.length <= 20) || 'Name must be less than 20 characters',
        ],
        price: [
          (v) => {
            if (!v) {
              return true;
            }
            return (Number(v) > 0 && !Number.isNaN(Number(v))) || 'Value is wrong';
          },
        ],
      };
    },
    updateRules() {
      return {
        name: [
          (v) => {
            if (!v) return true;
            return v.length <= 20 || 'Name must be less than 20 characters';
          },
        ],
        price: [
          (v) => {
            if (!v) {
              return true;
            }
            return /^[+]?([0-9]+(?:[.][0-9]*)?|\.[0-9]+)$/.test(v) || 'Value is wrong';
          },
        ],
      };
    },
    isUpdateMode() {
      return !!this.formData;
    },
    rules() {
      return this.isUpdateMode ? this.updateRules : this.createRules;
    },
  },
  created() {
    if (this.formData) {
      this.name = this.formData.name;
      this.price = this.formData.price || null;
    }
  },
  methods: {
    ...mapMutations('drinkOptions', ['DIALOG_TOGGLE']),
    ...mapActions('drinkOptions', ['createDrinkOption', 'updateDrinkOption']),
    onTypeName(val) {
      if (this.isUpdateMode && this.formData.name === val.trim()) {
        delete this.newData.name;
        return;
      }
      this.newData.name = val.trim();
    },
    onTypePrice(val) {
      if (this.isUpdateMode && this.formData.price === val.trim()) {
        delete this.newData.price;
        return;
      }

      if (/^[+]?([0-9]+(?:[.][0-9]*)?|\.[0-9]+)$/.test(val)) {
        this.newData.price = Number(val);
      } else {
        this.newData.price = 0;
      }
    },
    updateModeValidate() {
      if (!this.isUpdateMode) {
        return true;
      }
      return !!Object.keys(this.newData).length;
    },
    submitForm() {
      this.updatedDataError = !this.updateModeValidate();

      if (this.updatedDataError || !this.validForm) {
        return;
      }

      if (this.isUpdateMode) {
        const submitData = {
          data: this.newData,
          updatedRowId: this.formData.id,
        };
        this.updateDrinkOption(submitData);
        return;
      }

      this.createDrinkOption(this.newData);
    },
  },
};
</script>

<style scoped>

</style>
