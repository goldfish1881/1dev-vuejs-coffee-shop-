<template>
  <v-form
    ref="form"
    v-model="validForm"
  >
    <v-card-text>
      <v-container>
        <v-text-field
          :value="name"
          :rules="rules.name"
          label="Name"
          clearable
          @change="onTypeName"
        />
        <v-radio-group
          :value="selectionType"
          :rules="rules.selectionType"
          row
          label="Selection Type"
          @change="onChangeSelType"
        >
          <v-radio
            label="Single"
            value="single"
          />
          <v-radio
            label="Multiple"
            value="multiple"
          />
        </v-radio-group>
        <v-row align="center">
          <v-subheader>Is Required</v-subheader>
          <v-switch
            v-model="isRequired"
            inset
            :label="isRequired.toString()"
            :rules="rules.isRequired"
            class="text-capitalize"
          />
        </v-row>
        <v-autocomplete
          v-model="drinkOptions"
          label="Drink Options"
          :items="drinkOptionsList"
          :loading="drinkOptionsLoading"
          :rules="rules.drinkOptions"
          no-data-text="No found data"
          item-text="name"
          item-value="id"
          return-object
          cache-items
          clearable
          chips
          select-slot
          multiple
          :autocomplete="false"
        >
          <template v-slot:selection="{ item, index }">
            <v-chip
              v-if="index < 3"
              close
              @click:close="removeSelectedOption(index)"
            >
              <span>{{ item.name }}</span>
            </v-chip>
            <span
              v-if="index === 3"
              class="grey--text caption"
            >(+{{ drinkOptions.length - 3 }} others)</span>
          </template>
        </v-autocomplete>
      </v-container>
    </v-card-text>
    <v-card-actions>
      <span
        v-if="updatedDataError"
        class="red--text pl-5"
      >No modified data.</span>
      <v-spacer />
      <v-btn
        color="blue darken-1"
        text
        @click="DIALOG_TOGGLE()"
      >
        Cancel
      </v-btn>
      <v-btn
        :disabled="!validForm"
        color="blue darken-1"
        text
        @click="submitForm"
      >
        Save
      </v-btn>
    </v-card-actions>
  </v-form>
</template>

<script>
import { mapState, mapActions, mapMutations } from 'vuex';

export default {
  name: 'OptionGroupForm',
  data() {
    return {
      validForm: false,
      name: null,
      selectionType: null,
      isRequired: false,
      drinkOptions: [],
      updatedDataError: false,
      newData: {},
    };
  },
  computed: {
    ...mapState('optionGroups', ['formData']),
    ...mapState('drinkOptions', {
      drinkOptionsList: state => state.drinkOptions,
      drinkOptionsLoading: state => state.drinkOptionsLoading,
    }),
    createRules() {
      return {
        name: [
          v => !!v || 'Name is required',
          v => (v && v.length <= 20) || 'Name must be less than 20 characters',
        ],
        selectionType: [
          v => !!v || 'Selection type is required',
          (v) => {
            const types = ['single', 'multiple'];
            return types.includes(v) || `Selection type value must be ${types.join(' or ')}`;
          },
        ],
        isRequired: [
          v => typeof v === 'boolean' || 'Is Required field is required',
        ],
        drinkOptions: [
          values => Boolean(values && values.length) || 'Drink options is required',
        ],
      };
    },
    updateRules() {
      return {
        name: [
          (v) => {
            if (!v) return true;
            return v.length <= 20 || 'Name must be less than 20 characters';
          },
        ],
        selectionType: [
          (v) => {
            if (!v) return true;
            return v.length <= 100 || 'Description must be less than 100 characters';
          },
        ],
        isRequired: [
          v => typeof v === 'boolean' || 'Is Required field is required',
        ],
        drinkOptions: [
          (values) => {
            if (!values.length) return true;
            return Boolean(values && values.length) || 'Drink option is required';
          },
        ],
      };
    },
    isUpdateMode() {
      return !!this.formData;
    },
    rules() {
      return this.isUpdateMode ? this.updateRules : this.createRules;
    },
  },
  watch: {
    isRequired(val) {
      if (this.isUpdateMode && this.formData.isRequired === val) {
        delete this.newData.isRequired;
      } else {
        this.newData.isRequired = val;
      }
    },
    drinkOptions(newVal) {
      if (!Object.keys(newVal).length || this.isTheSameDrOptions(newVal)) {
        delete this.newData.options;
      } else {
        this.newData.options = newVal.map(item => item.id);
      }
    },
  },
  created() {
    if (this.formData) {
      this.name = this.formData.name;
      this.selectionType = this.formData.selectionType;
      this.isRequired = this.formData.isRequired;
      this.drinkOptions = this.formData.options.slice();
    }
    this.getDrinkOptions();
  },
  methods: {
    ...mapMutations('optionGroups', ['DIALOG_TOGGLE']),
    ...mapActions('optionGroups', ['createOptionGroup', 'updateOptionGroup']),
    ...mapActions('drinkOptions', ['getDrinkOptions']),
    onTypeName(val) {
      if (this.isUpdateMode && this.formData.name === val.trim()) {
        delete this.newData.name;
        return;
      }
      this.newData.name = val.trim();
    },
    onChangeSelType(val) {
      if (this.isUpdateMode && this.formData.selectionType === val) {
        delete this.newData.selectionType;
        return;
      }
      this.newData.selectionType = val;
    },
    removeSelectedOption(index) {
      this.$delete(this.drinkOptions, index);
    },
    isTheSameDrOptions(values) {
      let isTheSameIds;
      if (this.isUpdateMode && (Object.keys(values).length === this.formData.options.length)) {
        const valuesIdsArr = values.map(item => item.id);
        isTheSameIds = this.formData.options.every(item => valuesIdsArr.includes(item.id));
      }
      return isTheSameIds;
    },
    updateModeValidate() {
      if (!this.isUpdateMode) {
        return true;
      }
      return !!Object.keys(this.newData).length;
    },
    submitForm() {
      this.updatedDataError = !this.updateModeValidate();

      if (this.updatedDataError || !this.validForm) {
        return;
      }

      if (this.isUpdateMode) {
        const submitData = {
          data: this.newData,
          updatedRowId: this.formData.id,
        };
        this.updateOptionGroup(submitData);
        return;
      }
      if (this.newData.isRequired === undefined) {
        this.newData.isRequired = this.isRequired;
      }
      this.createOptionGroup(this.newData);
    },
  },
};
</script>

<style scoped>

</style>
