import LOGIN_USER from './mutation-types';

export default {
  // login
  [LOGIN_USER.PENDING]: (state) => {
    state.loginLoading = true;
    state.showError = false;
  },
  [LOGIN_USER.SUCCESS]: (state) => {
    state.isLoggedIn = true;
    state.loginLoading = false;
  },
  [LOGIN_USER.FAILED]: (state, error) => {
    state.loginLoading = false;
    state.showError = true;
    state.errorMsg = error.msg;
  },
};
