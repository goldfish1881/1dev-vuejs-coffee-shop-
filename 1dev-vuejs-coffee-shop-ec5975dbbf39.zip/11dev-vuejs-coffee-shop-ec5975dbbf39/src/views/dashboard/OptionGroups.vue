<template xmlns:v-slot="http://www.w3.org/1999/XSL/Transform">
  <div>
    <v-card
      class="mx-auto"
      max-width="1000"
    >
      <v-data-table
        class="elevation-1"
        :headers="datatable.headers"
        :items="optionGroups"
        :search="datatable.search"
        :loading="optionGroupsLoading"
        loading-text="Loading... Please wait"
        calculate-widths
        :options.sync="datatable.options"
        :server-items-length="optionGroups.length"
      >
        <template v-slot:top>
          <v-toolbar
            flat
            color="white"
          >
            <v-toolbar-title>Option Groups</v-toolbar-title>
            <v-divider
              class="mx-4"
              inset
              vertical
            />
            <v-spacer />
            <v-text-field
              :value="datatable.search"
              append-icon="mdi-magnify"
              label="Search"
              single-line
              hide-details
              class="mr-5"
              color="blue"
              @input="onDtbSearch"
            />
            <v-btn
              color="blue"
              outlined
              dark
              class="mb-2"
              @click.stop="DIALOG_TOGGLE()"
            >
              Add Option Group
            </v-btn>
          </v-toolbar>
        </template>
        <template v-slot:no-data>
          No data for showing
        </template>
        <template v-slot:item.selectionType="{ item }">
          {{ item.selectionType }}
        </template>
        <template v-slot:item.options="{ item }">
          <div>
            <span
              v-for="(op, i) in item.options"
              :key="i"
              class="mr-2"
            >
              {{ op.name }} {{ i + 1 !== item.options.length ? ',' : '' }}
            </span>
          </div>
        </template>
        <template v-slot:item.action="{ item }">
          <v-btn
            text
            icon
            color="blue"
            class="mr-2"
            @click="editOptionGroup(item.id)"
          >
            <v-icon>
              mdi-pencil
            </v-icon>
          </v-btn>
          <v-btn
            text
            icon
            color="red"
            class="mr-2"
            @click="deleteItem(item.id)"
          >
            <v-icon>
              mdi-delete
            </v-icon>
          </v-btn>
        </template>
      </v-data-table>
    </v-card>
    <v-dialog
      v-if="dialogOpen"
      :value="true"
      max-width="500px"
      persistent
      @keydown.esc="DIALOG_TOGGLE()"
    >
      <v-overlay
        absolute="absolute"
        :value="dialogLoading"
      >
        <v-progress-circular
          :size="50"
          color="primary"
          indeterminate
        />
      </v-overlay>
      <v-card>
        <v-card-title>
          <span class="headline">{{ formType }} Option Group</span>
          <v-spacer />
        </v-card-title>
        <option-group-form />
      </v-card>
    </v-dialog>
  </div>
</template>

<script>
import { mapState, mapActions, mapMutations } from 'vuex';
import OptionGroupForm from '@/views/dashboard/forms/optionGroup.vue';

export default {
  name: 'OptionGroups',
  components: {
    OptionGroupForm,
  },
  data() {
    return {
      datatable: {
        headers: [
          { text: 'Name', value: 'name', sortable: false },
          { text: 'Selection Type', value: 'selectionType', sortable: false },
          { text: 'Required', value: 'isRequired', sortable: false },
          { text: 'Options', value: 'options', sortable: false },
          {
            text: 'Actions', value: 'action', sortable: false, align: 'center',
          },
        ],
        search: '',
        options: {},
      },
    };
  },
  computed: {
    ...mapState('optionGroups', ['optionGroups', 'optionGroupsLoading', 'dialogLoading', 'dialogOpen', 'formData']),
    formType() {
      return this.formData ? 'Edit' : 'Add';
    },
  },
  watch: {
    'datatable.options': {
      handler() {
        this.getOptionGroups({ ...this.datatable.options, search: this.datatable.search });
      },
      deep: true,
    },
  },
  methods: {
    ...mapMutations('optionGroups', ['DIALOG_TOGGLE', 'ON_EDIT_OP_GROUP_ROW']),
    ...mapActions('optionGroups', ['getOptionGroups', 'deleteOptionGroup']),
    onDtbSearch(str) {
      if (!str || str.trim()) {
        this.getOptionGroups({ ...this.datatable.options, search: str.trim() });
      }
      this.datatable.search = str.trim();
    },
    editOptionGroup(id) {
      const rowData = Object.assign({}, this.optionGroups.find(item => item.id === id));

      if (Object.keys(rowData).length) {
        this.ON_EDIT_OP_GROUP_ROW(rowData);
      }
    },
    deleteItem(id) {
      if (id) {
        this.deleteOptionGroup(id);
      }
    },
  },
};
</script>

<style scoped>

</style>
