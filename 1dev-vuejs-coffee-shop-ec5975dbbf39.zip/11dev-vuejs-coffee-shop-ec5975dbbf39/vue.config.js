const path = require('path');

module.exports = {
  transpileDependencies: [
    'vuetify',
  ],
  configureWebpack: {
    resolve: {
      alias: {
        '@': path.resolve(__dirname, 'src'),
        styles: path.resolve(__dirname, './src/assets/styles'),
        images: path.resolve(__dirname, './src/assets/images'),
      },
    },
  },
};
