<template>
  <div>
    <h1>
      404 Page not found
    </h1>
  </div>
</template>

<script>
export default {
  name: 'PageNotFound',
};
</script>

<style scoped></style>
